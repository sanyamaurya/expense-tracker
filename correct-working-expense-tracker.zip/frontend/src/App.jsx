import React,{useEffect,useState} from 'react';
import axios from 'axios';

export default function App(){
 const [items,setItems]=useState([]);
 const [title,setTitle]=useState('');
 const [amount,setAmount]=useState('');

 async function load(){ setItems((await axios.get('/api/expenses')).data); }

 async function add(){
  if(!title||!amount) return;
  await axios.post('/api/expenses',{title,amount});
  setTitle(''); setAmount('');
  load();
 }

 async function del(id){
  await axios.delete('/api/expenses/'+id);
  load();
 }

 useEffect(()=>{load();},[]);

 return(<div style={{padding:20,fontFamily:'Arial'}}>
  <h1>Expense Tracker</h1>
  <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)}/>
  <input placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)}/>
  <button onClick={add}>Add</button>
  <ul>
   {items.map(x=><li key={x.id}>{x.title} - ₹{x.amount}
     <button onClick={()=>del(x.id)}>X</button></li>)}
  </ul>
 </div>);
}
